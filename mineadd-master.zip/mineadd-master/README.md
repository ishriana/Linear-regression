# COVID19
A flask web app that can predict the probability of a patient contracting COVID19.

# Live demo
Checkout how this App works [here](https://youtu.be/IRoOPAkJWVI).

# Article on how I made it.
Checkout the article I wrote [here](https://dev.to/rakshakannu/project-covid-19-5f23).
